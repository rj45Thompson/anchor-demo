"""Copy what the public manual page needs into the anchor-demo site (anchor-demo/memsentinel/), from its single sources:

- viewer.js and viewer.css from the plugin (the same files the plugin's own visual report inlines),
- sample.js: the merged report of site/sample/ (real findings files from the test game, unedited),
- the panel screenshots as JPEG, and the front page's thumbnail,
- the plugin zip (source plugin, no build outputs) and the full source zip.

    py tools/publish_site.py --site D:/code/anchor-demo
The page itself (anchor-demo/memsentinel/index.html) is written by hand and is not touched here.
"""
import argparse
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "unreal" / "MemorySentinel" / "Tools"))

from memsentinel.report import VIEWER, Report  # noqa: E402

VERSION = "1.0"
SKIP_PARTS = {"Binaries", "Intermediate", "Saved", "DerivedDataCache", "__pycache__", ".git", ".vs", "archive", "runs"}


def zip_tree(out: Path, base: Path, roots: list[Path], prefix: str) -> int:
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for r in roots:
            for p in sorted(r.rglob("*")):
                rel = p.relative_to(base)
                if p.is_dir() or SKIP_PARTS & set(rel.parts) or p.is_symlink():
                    continue
                if p.suffix in (".log", ".pyc") or p.name.endswith(".json") and "Saved" in rel.parts:
                    continue
                z.write(p, f"{prefix}/{rel.as_posix()}")
                n += 1
    return n


def main(argv):
    a = argparse.ArgumentParser()
    a.add_argument("--site", required=True)
    args = a.parse_args(argv)
    out = Path(args.site) / "memsentinel"
    out.mkdir(parents=True, exist_ok=True)

    for name in ("viewer.js", "viewer.css"):
        (out / name).write_text((VIEWER / name).read_text(encoding="utf-8"), encoding="utf-8")

    sample = sorted((ROOT / "site" / "sample").glob("*.json"))
    rep = Report.from_files(sample)
    if rep.problems or not rep.files:
        print("REFUSED: the sample set is unreadable:", rep.problems)
        return 2
    # the files are published as they were written, except this machine's folders, which are shortened (the page says so)
    data = json.dumps(rep.data())
    for long, short in ((str(ROOT / "unreal").replace("\\", "\\\\") + "\\\\", ""), (str(ROOT / "unreal").replace("\\", "/") + "/", ""),
                        ("d:/_memsentinel/unreal/", ""), ("D:\\\\_memsentinel\\\\unreal\\\\", ""), ("d:\\\\_memsentinel\\\\unreal\\\\", ""),
                        ("d:\\\\Program Files\\\\Epic Games\\\\", ""), ("D:\\\\Program Files\\\\Epic Games\\\\", ""),
                        ("D:\\\\_memsentinel\\\\", ""), ("D:/_memsentinel/", "")):
        data = data.replace(long, short)
    left = [w for w in (ROOT.name, Path.home().name, "Program Files") if w in data]
    if left:
        print("REFUSED: machine paths left in the sample:", left)
        return 2
    data = data.replace("</", "<\\/")
    (out / "sample.js").write_text("window.MEMSENTINEL_SAMPLE = " + data + ";\n", encoding="utf-8")

    from PIL import Image
    shots = out / "shots"
    shots.mkdir(exist_ok=True)
    for png in sorted((ROOT / "site" / "shots").glob("*.png")):
        Image.open(png).convert("RGB").save(shots / (png.stem + ".jpg"), "JPEG", quality=86, optimize=True)
    thumb = Image.open(ROOT / "site" / "shots" / "panel-leak.png").convert("RGB")
    w, h = thumb.size
    box = (int(w * 0.02), int(h * 0.03), int(w * 0.98), int(h * 0.03) + int(w * 0.96 * 400 / 640))
    thumb.crop(box).resize((640, 400), Image.LANCZOS).save(Path(args.site) / "thumbs" / "memsentinel.jpg", "JPEG", quality=86, optimize=True)

    plugin = ROOT / "unreal" / "MemorySentinel"
    n1 = zip_tree(out / f"MemorySentinel-UE5.7-v{VERSION}.zip", plugin.parent, [plugin], "Plugins")
    for extra in ("LICENSE", "README.md"):
        with zipfile.ZipFile(out / f"MemorySentinel-UE5.7-v{VERSION}.zip", "a") as z:
            z.write(ROOT / extra, f"Plugins/MemorySentinel/{extra}")
    n2 = zip_tree(out / f"memsentinel-source-v{VERSION}.zip", ROOT,
                  [ROOT / "unreal" / "MemorySentinel", ROOT / "unreal" / "SentinelTest" / "Source",
                   ROOT / "unreal" / "SentinelTest" / "Config", ROOT / "tests", ROOT / "tools"], "memsentinel")
    # spec/ stays out: the design notes it quotes are private working notes
    with zipfile.ZipFile(out / f"memsentinel-source-v{VERSION}.zip", "a") as z:
        for extra in ("LICENSE", "README.md", "USE_CASES.md", "unreal/SentinelTest/SentinelTest.uproject"):
            z.write(ROOT / extra, f"memsentinel/{extra}")
    print(f"published to {out}: viewer, sample.js ({len(rep.files)} files, {len(rep.findings)} findings), "
          f"{len(list(shots.glob('*.jpg')))} shots, plugin zip ({n1 + 2} files), source zip ({n2 + 4} files)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
