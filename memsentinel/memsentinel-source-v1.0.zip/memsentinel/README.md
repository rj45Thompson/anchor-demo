# Memory Sentinel

Find Unreal Engine 5 memory bugs before your players do: UObject pointers the garbage collector cannot see, shared pointer
cycles, objects that outlive the level that made them, and heap stomps (writes past the end of a block, after a free, or a
double free), each reported with the file and line, how it is known, and what to change.

- **Static pass** (Python, standard library; runs on the Python inside every Unreal install): reads your project's C++ and
  reports raw `UObject*` / `TObjectPtr` members without `UPROPERTY`, UObject pointers in plain structs and `FGCObject`s that
  forget one, lambdas handed to timers and delegates that capture a UObject unguarded, UObjects hidden in `void*`, and
  `TSharedPtr` cycles between types (including through a base class).
- **Level leak test**: opens a map, leaves it, collects garbage twice, and lists what survived. For each survivor, the
  engine's own reference search (the code behind `obj refs`) gives the chain from a root.
- **Heap sampler** (`-MemorySentinel`): one allocation in N, and every allocation of a size you suspect, gets a canary after
  its end; freed blocks wait in quarantine filled with a pattern; the CPU's four data breakpoints rotate over the likeliest
  blocks and stop the exact write; optional GWP-ASan style guard pages fault at the exact instruction.
- **Panel**: Tools > Memory Sentinel in the editor, or `ms.Show` in a running game, with a diagram for every finding. **Visual
  report**: one HTML file for the build server.

Manual and a live report: https://rj45thompson.github.io/anchor-demo/memsentinel/

## Install

1. Copy `unreal/MemorySentinel` into your project's `Plugins/` folder.
2. Regenerate project files and build your editor target (Windows x64, Unreal 5.7).
3. Tools > Memory Sentinel.

From a script or CI:

```
python Plugins/MemorySentinel/Tools/ms.py scan <project folder>
python Plugins/MemorySentinel/Tools/ms.py leaktest --project <P.uproject> --map /Game/Maps/YourMap
python Plugins/MemorySentinel/Tools/ms.py heap --project <P.uproject> --map /Game/Maps/YourMap --seconds 60
python Plugins/MemorySentinel/Tools/ms.py report <project>/Saved/MemorySentinel -o report.html
```

Exit codes: 0 nothing at or above `--fail-on`, 1 findings, 2 the detector could not run (never a clean pass).

## What is in this repository

- `unreal/MemorySentinel`: the plugin (three modules: `MemorySentinelHeap`, `MemorySentinel`, `MemorySentinelEditor`) and
  its Python tools (`Tools/ms.py`, `Tools/memsentinel/`).
- `unreal/SentinelTest`: the test game. Every bug the tool must find is planted there on purpose, beside a clean copy of each
  pattern that must produce nothing.
- `tests/`: the static pass held to the test game both ways (every plant found at its line, nothing else reported), and edge
  cases one snippet at a time.
- `USE_CASES.md`: the use cases, requirements and the classes that serve each step.
- `spec/` (in the working copy, not in the public zip): the design notes the tool was built from, and the spec check (rules
  quoted from the notes, one repro per rule, each run against the shipped tool).

## Measured

- Test game, static pass: 18 planted bugs, 18 reported at their lines, 0 reports in the clean control.
- Level leak test: the planted per-level cache is reported with its full chain (GameEngine, GameInstance, the subsystem's
  `Caches` array); the same map with nothing planted reports no survivor out of about 43,000 live objects.
- Heap sampler: the planted overrun, write after free, double free and guarded overrun are each reported, the overrun and the
  write after free at the exact writing line; with nothing planted, sampling 1 in 4 with guard pages over two map travels
  (19 million allocations, 67,355 canaries, 5,067 guard pages, 27 register rotations), no finding.
- Spec check: 13 rules quoted from the notes, 19 repros, every one kept; three planted faults in a copy of the tool each turn
  their repros red.

What it cannot see is listed in every report it writes.

MIT licence.
